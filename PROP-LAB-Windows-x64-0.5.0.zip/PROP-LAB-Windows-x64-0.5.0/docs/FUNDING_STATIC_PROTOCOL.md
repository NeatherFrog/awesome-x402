# Frozen static carry collateral protocol

One new structural construction, prior failures and gates preserved.2025 is explicitly reused;2026 funding outcomes remain unopened.

```json
{
  "version": "funding-static-collateral-v1",
  "frozen_at": "2026-10-02T09:59:12.915265Z",
  "lineage_protocol_sha256": "70afef903117b3b1421602055421e0f8f6b55d1dbcbc66a6f8f6e6c9746163c1",
  "lineage_report_sha256": "44e24a04a4f1eb42183d33dad7a6829d974ca1c26969caf33463dd6cd88632b5",
  "lineage_sized_protocol_sha256": "9d9a6d768376725a860d2725919e3b497ceb2970150cf425b07f653eebc85ba7",
  "lineage_sized_report_sha256": "c0cd965d447074c20662cdd94ac314db765e84398f8be86a3a1387b8131881a5",
  "producers": {
    "propdesk/funding_lab.py": "211642137591cfb735495f2d98375ef0856e3962284d90c5df8eb517fc16aa76",
    "scripts/research_funding.py": "e91c16924ab86d9ba3d92a943611a8f7a6381ce71d3407e9cc8113d26e121998",
    "propdesk/research_stats.py": "1beee93dc5d400ccb7c4967c649c5d7b64d68a6456150ca68bdf038dd18dee16",
    "propdesk/funding_sized.py": "11921dda2abac16c809111e99b612ae53abaa039220eafb3079810ed9c098a0c",
    "scripts/research_funding_sized.py": "d1ef0c68a2adddb14e43b1aa7cff0459f93d84bcaef990e5906b0d3d8ed8ba00",
    "propdesk/funding_static.py": "88a85628741c3a67160d48223f0229e7a1eadfe35adb6d1dcf0da6687bea6659",
    "scripts/research_funding_static.py": "f2157e935e0547e1d8692d2eafdbbfe0aaefb81f7358c045729361dd1a28535a"
  },
  "windows": {
    "training": [
      "2024-01-01T00:00:00Z",
      "2025-01-01T00:00:00Z"
    ],
    "validation": [
      "2025-01-01T00:00:00Z",
      "2026-01-01T00:00:00Z"
    ],
    "final": [
      "2026-01-01T00:00:00Z",
      "2026-10-01T00:00:00Z"
    ]
  },
  "variants": [
    {
      "id": "static",
      "lookback": 0,
      "entry_rate": 0.0,
      "margin_reduction": false
    }
  ],
  "cases": {
    "base": [
      1.0,
      1.0
    ],
    "cost_stress": [
      2.0,
      1.0
    ],
    "funding_stress": [
      1.0,
      0.75
    ]
  },
  "trial_accounting": "Seven original funding variants plus seven half-active variants plus ONE static-collateral hypothesis equals15 sequential funding hypotheses. All prior trading research remains additional selection history.",
  "calibration": "Original2024 static hedge suffered isolated liquidation;2025 half-active persistence winner lost with138 leg fills,992USD fees versus1020USD funding. Choose20% spot/80% collateral per asset and constant hold to reduce turnover and add physical collateral.2024 and2025 are known adaptive calibration/exploratory data, never blind evidence.2026 funding performance remains unopened until the fixed reused2025 gate and immutable confirmation.",
  "capital": {
    "total_account": 100000,
    "btc_bucket": 50000,
    "eth_bucket": 50000,
    "spot_fraction_per_bucket": 0.2,
    "derivative_fraction_per_bucket": 0.8,
    "spot_cash_per_asset": 10000,
    "isolated_derivative_cash_per_asset": 40000,
    "idle_external_cash": 0,
    "cash_interest": 0,
    "cross_wallet_transfers": false,
    "spot_profit_can_rescue_margin": false
  },
  "arithmetic": "At each calendar close and conservative worst mark, total equity is the sum of two physical50k asset buckets. Spotcash+derivativecash+spot market value+short unrealized PnL, with fees and actual settled funding. No extra idle capital or synthetic collateral. Compute daily/account risk/inference from successive total dollar equity.",
  "selection": "Evaluate seven variants in2024, require positive base/doubled-cost/75%-positive-funding return,>=200 credited settlements, zero modeled liquidations,<=5% drawdown,<=2.5% daily envelope drawdown. ChooseONE by return/max(drawdown,.25), then lexicographicID. Persist selection hash BEFORE2025 simulation. No replacement if2025 fails. Persist confirmation hash BEFORE2026 simulation; never open2026 performance if validation fails.",
  "validation_final_gates": "Positive base/doubled-cost/75%-positive-funding return;>=180 full calendar days and>=6months;>=200 funding settlements; zero modeled liquidations;99%7-day block mean CI lower>0; both chronological halves positive; largest positive month share<=.5;<=5% maxdrawdown and<=2.5% daily envelope; per-asset beta absolute<=.1. Candidate remains provisional, live/propfalse.",
  "execution_signals_funding_margin": "Literal copy of original frozen simulate: only spotcash=capital*.2, collateral=capital*.8 and spotbudget=capital*.2 differ. Single static variant enters no earlier than next hour after a known closed bar, then constant equalbase units; no rate-based exits or defensive reductions. Negative settlements paid fully. Original two-leg fees, separate-wallet bookkeeping, pre-settlement conservative liquidation,1minute funding entitlement delay and prior closed-trade-price funding mark proxy unchanged. Final boundary close hypothetical, no entry at last bar.",
  "selection_procedure": "Evaluate EXACTLY ONE2024 construction. Preserve original basic/confirmation gates and never tune risk thresholds. Persist immutable choice before reused2025 outcomes. Only if reused2025 passes ALL original confirmation gates persist its immutable hash and open the single2026 funding evaluation. No alternative or exposure change after failure; stop expanding carry hypotheses after this study.",
  "inference": "Dailycalendar returns includingflatdays;5000circular7dayblocks,99%CI seed20261002; inferenceapproxconditionalstationarity, noindependenceclaim. Seven adaptivevariantsandallpriorstudiesremainselectionuncertainty. Perassetregressionbeta/correlationdescriptive, notcausalproof.",
  "friction": {
    "spot_fee_bps": 10,
    "perp_fee_bps": 5,
    "slippage_bps": 2,
    "full_spread_bps": 1,
    "stress_multiplier": 2,
    "positive_funding_stress_multiplier": 0.75,
    "negative_funding_stress": "Unchanged; no loss discount",
    "status": "Illustrative conservative assumptions, notverified tariffs/filters"
  },
  "data": "SamevenueofficialBinancespot1h andUSD-Mperpetual1h closedcandles full2024Jan\u20132026Sep; fundingsettlementarchive actualrates/intervals. ImmutableSHA256receiptsandchecksums required. Allhourlytimestampsmustmatch; no gaps/imputation/date deletion. Knownfundingintervalschecksettlementgaps. NullintervalallowedonlyverifiedexhaustiveofficialRESTpaginationreceipt; expectedintervalunknownrecorded, neverinvent8h or missingrate. Finalboundarypositionsclosedhypothetically, noentrylastbar.",
  "permissions": "PersonalnonproductionCCBYNCSAarchivalresearch; noactualaccounts/orders/purchases/Telegram/credentials. Requireverifiedlicensedproductionfeedandprospectivepaperdata beforelive.",
  "limitations": "Adaptive construction after inspected2025 failure and15 sequential carry hypotheses; finite collateral, imperfect funding/liquidation marks, executable tariffs/filters and venue default/outage risk unverified.2026 is not globally blind because other research inspected its market period. Passing means only a historical provisional candidate requiring fresh forward data; no stable future profit/live/prop certification."
}
```
